# android.com sample

## Why this sample
The goal of this sample is to illustrate implementing a real-world-looking site with **Material Design Lite**.

We therefore decided to do a cover of the front page of the android.com website, which while not a 1:1 match illustrates MDL usage well.
