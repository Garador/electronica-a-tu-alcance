---
layout: started
title: Getting started
bodyclass: started
include_prefix: ../
snippets:
  - component_name: button
    snippet_group:
    - caption: Raised button
      file: raised-ripple-accent.html
    - caption: Colored FAB
      file: fab-colored.html
---
